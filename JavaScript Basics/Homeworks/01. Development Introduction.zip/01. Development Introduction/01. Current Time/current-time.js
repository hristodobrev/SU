var date = new Date();
console.log(date.toUTCString());