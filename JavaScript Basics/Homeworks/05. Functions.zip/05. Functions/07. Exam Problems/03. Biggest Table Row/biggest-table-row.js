function solve(input) {
    var splited = input.split('\n');
    var regex = /<tr><td>.*?<\/td><td>(.*?)<\/td><td>(.*?)<\/td><td>(.*?)<\/td><\/tr>/g;
    var match;
    var maxSum = 0;
    var output;
    while(match = regex.exec(splited)) {
        var sum = 0;
        var numsAsStrings = [];
        if(!isNaN(Number(match[1]))) {
            sum += Number(match[1]);
            numsAsStrings.push(match[1]);
        }
        if(!isNaN(Number(match[2]))) {
            sum += Number(match[2]);
            numsAsStrings.push(match[2]);
        }
        if(!isNaN(Number(match[3]))) {
            sum += Number(match[3]);
            numsAsStrings.push(match[3]);
        }
        if(sum > maxSum) {
            maxSum = sum;
            output = maxSum + ' = ' + numsAsStrings.join(' + ');
        }
    }

    console.log(output);
}