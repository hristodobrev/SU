INSERT INTO blog.users (username, password, fullname) VALUES ('Pesho', '202cb962ac59075b964b07152d234b70', 'Petar Petrov');
INSERT INTO blog.users (username, password, fullname) VALUES ('Gosho', 'caf1a3dfb505ffed0d024130f58c5cfa', 'Georgi Georgiev');
INSERT INTO blog.users (username, password, fullname) VALUES ('Tosho', 'c4ca4238a0b923820dcc509a6f75849b', 'Todor Todorov');
INSERT INTO blog.users (username, password, fullname) VALUES ('Mariika', 'c81e728d9d4c2f636f067f89cc14862c', 'Mariya Mariyova');
INSERT INTO blog.users (username, password, fullname) VALUES ('Stamat', 'eccbc87e4b5ce2fe28308fd9f2a7baf3', 'Stamat Stamatov');
INSERT INTO blog.users (username, password, fullname) VALUES ('pepi', '$xyz', 'Peter Ivanov');
INSERT INTO blog.users (username, password, fullname) VALUES ('Penka', '4b474fa55a02e1518dc055c6272bd4e4', 'Penka Ivanova');