<?php $this->title = "Post Title" ?>

<h1><?=htmlspecialchars($this->title)?></h1>

<!-- TODO: display a single post here -->
