<?php

class HomeController extends BaseController
{
    function index() {
        // TODO: Load posts to be displayed here ...
    }
	
	function view($id) {
        // TODO: Load a post to be displayed here ...
    }
}
