USE Blog

UPDATE Posts
SET Title = 'Post Title Updated'
WHERE ID = 1009

UPDATE Users
SET FullName = 'Georgi Iliev'
WHERE ID = 6