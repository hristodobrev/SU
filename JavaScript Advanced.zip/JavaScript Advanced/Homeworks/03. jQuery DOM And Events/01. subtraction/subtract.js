function subtract(){
    let num1 = Number($('#firstNumber').val());
    let num2 = Number($('#secondNumber').val());
    $('#result').text(num1 - num2);
}