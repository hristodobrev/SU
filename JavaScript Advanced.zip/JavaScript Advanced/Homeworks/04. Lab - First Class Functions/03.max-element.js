function maxElement(arr) {
    return Math.max.apply(null, arr);
}

commandProcessor([1, 44, 123, 33]);