﻿namespace _15.SOLID_Principles.Enumerations
{
    public enum ReportLevel
    {
        Info = 0,
        Warn = 1,
        Error = 2,
        Critical = 3,
        Fatal = 4
    }
}
