result.Turtle = require('./turtle');
result.WaterTurtle = require('./water-turtle');
result.GalapagosTurtle = require('./galapagos-turtle');
result.EvkodianTurtle = require('./evkodian-turtle');
result.NinjaTurtle = require('./ninja-turtle');