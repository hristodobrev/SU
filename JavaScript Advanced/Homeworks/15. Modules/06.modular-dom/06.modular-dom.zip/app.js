result.BaseElement = require('./base-element');
result.TitleBar = require('./title-bar');
result.Footer = require('./footer');
result.Article = require('./article');
result.ImageArticle = require('./image-article');
result.TableArticle = require('./table-article');