﻿using System;

namespace _01.Shapes.Interfaces
{
    public interface IShape
    {
        double CalculateArea();

        double CalculatePerimeter();
    }
}
