﻿namespace TheSlum
{
    using GameEngine;
    using System.Collections.Generic;

    public class Program
    {
        public static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
