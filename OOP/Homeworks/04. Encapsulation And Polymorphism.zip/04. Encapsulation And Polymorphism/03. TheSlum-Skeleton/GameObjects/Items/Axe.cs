﻿namespace TheSlum
{
    public class Axe : Item
    {
        public Axe(string id)
            : base(id, 0, 0, 75)
        {
        }
    }
}
