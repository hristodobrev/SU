﻿using System;

namespace _02.Bank_Of_Kurtovo_Konare.Interfaces
{
    public interface ILoanAccount
    {
        void Deposit(decimal ammount);
    }
}
