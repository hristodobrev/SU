﻿using System;

namespace _02.Bank_Of_Kurtovo_Konare.Customers
{
    public abstract class Customer
    {

    }
}
