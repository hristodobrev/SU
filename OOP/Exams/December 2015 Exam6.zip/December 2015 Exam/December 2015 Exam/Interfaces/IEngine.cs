﻿namespace December_2015_Exam.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
