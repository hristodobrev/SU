﻿namespace Empires.UI.Interfaces
{
    public interface IWritter
    {
        void Write(string message);
    }
}
