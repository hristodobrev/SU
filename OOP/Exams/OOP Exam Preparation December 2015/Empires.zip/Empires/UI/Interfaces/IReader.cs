﻿namespace Empires.UI.Interfaces
{
    public interface IReader
    {
        string Read();
    }
}
