﻿namespace Empires.Units
{
    public class Archer : Unit
    {
        public Archer()
            : base(25, 7)
        {

        }
    }
}
