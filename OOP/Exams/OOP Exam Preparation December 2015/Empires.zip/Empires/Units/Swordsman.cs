﻿namespace Empires.Units
{
    public class Swordsman : Unit
    {
        public Swordsman()
            : base(40, 13)
        {

        }
    }
}
