﻿namespace December_2015_Exam.Constants
{
    public static class Constants
    {
        public static bool useEvents = false;
    }
}
