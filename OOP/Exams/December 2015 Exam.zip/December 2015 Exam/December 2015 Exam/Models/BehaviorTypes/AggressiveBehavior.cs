﻿namespace December_2015_Exam.Models.BehaviorTypes
{
    using December_2015_Exam.Interfaces;

    public class AggressiveBehavior : IBehavior
    {
        private static int decreasingDamage = 5;

        public AggressiveBehavior()
        {
            this.Triggered = false;
        }

        public void UpdateStats(IBlob parent)
        {
            if (!this.Triggered &&
                parent.Health <= parent.InitialHealth / 2)
            {
                parent.Damage *= 2;
                this.Triggered = true;
                return;
            }

            if (this.Triggered)
            {
                if (parent.Damage > parent.InitialDamage)
                {
                    parent.Damage -= decreasingDamage;
                }

                if (parent.Damage < parent.InitialDamage)
                {
                    parent.Damage = parent.InitialDamage;
                }
            }
        }

        public bool Triggered { get; private set; }
    }
}
