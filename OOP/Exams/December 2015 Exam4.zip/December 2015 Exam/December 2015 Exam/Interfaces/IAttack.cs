﻿namespace December_2015_Exam.Interfaces
{
    public interface IAttack
    {
        int ProduceAttack(IBlob parent);
    }
}
