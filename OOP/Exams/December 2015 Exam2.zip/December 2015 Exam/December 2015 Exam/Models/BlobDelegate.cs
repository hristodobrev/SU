﻿namespace December_2015_Exam.Models
{
    using December_2015_Exam.Interfaces;

    public delegate void BlobDelegate(IBlob parent);
}