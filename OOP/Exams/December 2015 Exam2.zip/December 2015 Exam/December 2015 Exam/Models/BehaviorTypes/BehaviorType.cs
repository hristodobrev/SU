﻿namespace December_2015_Exam.Models.BehaviorTypes
{
    using December_2015_Exam.Interfaces;

    public abstract class BehaviorType : IBehavior
    {
        public event BlobDelegate Toggled;

        public BehaviorType()
        {
            if (Constants.Constants.UseEvents)
            {
                this.Toggled += InflatedBehavior_Toggled;
            }
        }

        private void InflatedBehavior_Toggled(IBlob parent)
        {
            System.Console.WriteLine("Blob {0} toggled {1}", parent.Name, parent.BehaviorType.GetType().Name);
        }

        protected void FireEvent(IBlob parent)
        {
            if (this.Toggled != null)
            {
                this.Toggled(parent);
            }
        }

        public abstract void UpdateStats(IBlob parent);

        public bool Triggered { get; protected set; }
    }
}
