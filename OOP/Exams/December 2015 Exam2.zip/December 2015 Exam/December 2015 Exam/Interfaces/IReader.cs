﻿namespace December_2015_Exam.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}
