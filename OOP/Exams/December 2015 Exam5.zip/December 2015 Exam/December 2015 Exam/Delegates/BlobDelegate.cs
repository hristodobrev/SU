﻿namespace December_2015_Exam.Delegates
{
    using December_2015_Exam.Interfaces;

    public delegate void BlobDelegate(IBlob parent);
}
